@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul || (echo ERROR: Node.js was not found. & exit /b 1)
where ffmpeg >nul 2>nul || (echo ERROR: ffmpeg was not found in PATH. & exit /b 1)

if not exist node_modules (
  call npm install || exit /b 1
  call npx playwright install chromium || exit /b 1
)

if /I "%~1"=="preview" (
  call npm run preview || exit /b 1
) else (
  call npm run render || exit /b 1
)
endlocal
