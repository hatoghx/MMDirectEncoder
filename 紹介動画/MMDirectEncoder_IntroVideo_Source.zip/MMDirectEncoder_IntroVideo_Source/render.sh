#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

command -v node >/dev/null || { echo "ERROR: Node.js was not found." >&2; exit 1; }
command -v ffmpeg >/dev/null || { echo "ERROR: ffmpeg was not found in PATH." >&2; exit 1; }

if [ ! -d node_modules ]; then
  npm install
  npx playwright install chromium
fi

if [ "${1:-}" = "preview" ]; then
  npm run preview
else
  npm run render
fi
