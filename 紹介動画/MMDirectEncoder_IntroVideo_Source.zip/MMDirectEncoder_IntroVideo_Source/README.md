# MMDirectEncoder 紹介動画 レンダリング一式

HTML で描いた各シーンを Chromium (Playwright) で 1 フレームずつ撮影し、ffmpeg で MP4 に書き出します。

| 項目 | 値 |
|---|---|
| 尺 | 129 秒 (2:09) |
| 解像度 / fps | 1920x1080 / 30fps (3870 フレーム) |
| 出力 | H.264 (libx264, CRF 16, yuv420p, BT.709), MP4 |
| 音声 | なし (字幕のみ) |

## 必要なもの

- Node.js 18 以上
- ffmpeg (PATH が通っていること、libx264 有効のビルド)
- インターネット接続 (初回の `npm install` と Chromium 取得のみ)

## 使い方 (Windows)

```
render.cmd           本番レンダリング (MMDirectEncoder_IntroVideo.mp4 を出力)
render.cmd preview   確認用の静止画を preview\ に出力
```

初回は `npm install` と `npx playwright install chromium` が自動で実行されます。

## 使い方 (macOS / Linux)

```
./render.sh
./render.sh preview
```

## 手動で実行する場合

```
npm install
npx playwright install chromium
node render.js preview 4 15 31      指定秒の静止画を preview/ に出力
node render.js full out.mp4         全編を out.mp4 に出力
```

## ファイル構成

| ファイル | 役割 |
|---|---|
| index.html | 全 10 シーンの構成・デザイン・アニメーション。`render(t)` で時刻 t の画面を決定的に描画 |
| render.js | Playwright でページを開き、フレームごとに `render(t)` → 撮影 → ffmpeg へパイプ |
| icon.png | リポジトリの `img/icon.ico` から抽出した 512x512 画像 |
| package.json | 依存 (playwright, フォント 3 種) と npm スクリプト |
| render.cmd / render.sh | 依存の導入とレンダリングをまとめて実行 |
| LEARNINGS.md | 制作過程で整理した内容 |

## 編集の要点

- シーンの開始・終了は `<section data-start data-end>`、要素の登場は `data-in` (秒) / `data-dur` (秒) / `data-fx` (`up` / `left` / `scale` / `fade`) で指定します。
- 全体の尺は `index.html` 内の `TOTAL` と最後のシーンの `data-end` を合わせて変更します。
- フォントは `node_modules/@fontsource-variable/*` を相対パスで読み込みます。`node_modules` を削除した場合は `npm install` をやり直してください。
- 所要時間の目安: 4 コアで約 6 分 30 秒。
